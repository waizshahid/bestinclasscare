import { products } from './data';
import Header from "./header";
import CardList from './card-list';
// import { Switch, Route } from "react-router-dom";
import { useState } from 'react'
import Product from './product';


function App() {
  return (
    <>
 
          
      <div style={{ backgroundColor: "white" }}>
        <Header />

        {/* <Switch>
        <Route exact path="/"> */}
        
        <CardList products={products} />

        {/* <Route exact path="/register">
          <Register />
        </Route>
      </Switch> */}

{/*         
<Product  /> */}

      </div>




    </>
  );
}

export default App;





