import { useState } from 'react';

import { findProductById }  from "./data";
// import PageTitleBar from "./page-title-bar";
// import Counter from './counter'

import { Icon, InlineIcon } from '@iconify/react';
import questionMark from '@iconify-icons/oi/question-mark';

import {Container,Col,Row} from "react-bootstrap"

function Product(props) {

    // const id = props.match.params.id
    
    // const [product] = useState(() => findProductById(id))
    

    // if (!product)
    //     return <h1>No product found for id {id}</h1>

    return (
        <>
           
           
            {/* -------------------------------detail page part  (product)----------------------------------------------------------           */}

   
      <h>Services Provided</h>
   
   <div    style={{display: "inline-block" ,  }}    > <Icon icon="akar-icons:wifi" color="black" width="25" height="25" hFlip={true}    /> 
    <p           style={{color: "lightgrey",  }}        > wifi : </p>  </div>


    <p  style={{color: "lightgrey",  }}> parking: <span  style={{color:"black"}}> {}  <Icon icon="mdi:alpha-p" color="black" width="25" height="25" rotate={2} hFlip={true} vFlip={true} />  </span></p>           
    <p  style={{color: "lightgrey",  }}>coffe  : <span  style={{color:"black"}}> {}  <Icon icon="jam:coffee-cup-f" />   </span></p>           
   
   <span> <p  style={{color: "lightgrey",  }} >language service   : <span  style={{color:"black"}}> {}  <Icon icon="jam:world" color="black" width="25" height="25" rotate={2} hFlip={true} vFlip={true} />   </span></p>           
    <p  style={{color: "lightgrey",  }}>curabetur est  : <span  style={{color:"black"}}> {}  <Icon icon="bx:bx-handicap" color="black" width="25" height="25" rotate={2} hFlip={true} vFlip={true} />   </span></p>           
    <p  style={{color: "lightgrey",  }} >proin mollis  : <span  style={{color:"black"}}> {}  <Icon icon="icon-park-outline:medical-box" color="black" width="25" height="25" rotate={2} hFlip={true} vFlip={true} />  </span></p>          </span> 
   
    <hr/>

    <p  style={{color: "lightgrey",  }}>description : <span  style={{color:"lightgrey"}}> {props.product.description}</span></p>













           {/* <div>
      <div className="card shadow-sm" style={{flexDirection:"row"}}>
      <Col sm={4} lg={12}>
    
     
        <img   className="card-img-top" src={props.product.image} /></Col>
        <div className="card-body">
         
          <p className="card-text">
          <Col sm={8}>
              
            <hr/>
            

          </Col>
          </p>
          <div className="d-flex justify-content-between align-items-center">
            <div className="btn-group w3-button w3-teal">
            {/* <Link to={`/detail-page/${props.product.id}`} ></Link> */}
          {/* <strong style={{color: "lightblue",  }}    >  {props.product.title }  </strong>
              
         <p style={{color: "lightgrey",  }}  ><div >distance: <span style={{color:"black"}}>{props.product.distance}</span></div></p>
         <p style={{color: "lightgrey",  }}>Address : <span  style={{color:"black"}}>{props.product.Address}</span>   </p>
         <p  style={{color: "lightgrey",  }}>Phone :<span  style={{color:"black"}}>{props.product.Phone}</span>  </p>
         <p  style={{color: "lightgrey",  }}>description : <span  style={{color:"black"}}> {props.product.description}</span></p>
              
              
                          </div>
<hr/>
                           <br/>
          </div>
        </div>
      </div>
    </div> */}
 







           
           
        </>
    )
}
export default Product;