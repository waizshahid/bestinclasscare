import "./App.css"
export default function Header() {
  return (

    <div class="container">
      <h2 id="head">Choice Hospital</h2>
      <h3 id="para" > based on the information you've provided here are result local to you that may be able to offer care at low or no out of pocket cost to you. </h3>
   <div class ="center"  > <button id="button" > Contact Care Conciege </button></div>
    </div>
  );
}
